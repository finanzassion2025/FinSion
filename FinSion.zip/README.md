# FinSion

Aplicación para control de ingresos y egresos con análisis por categorías.

Creado con React y TailwindCSS.